export class MarvelService {

  readonly BASE_URL = 'https://gateway.marvel.com/v1/public';

  constructor() {
  }
}
