export interface Power {
  id: number;
  name: string;
}
