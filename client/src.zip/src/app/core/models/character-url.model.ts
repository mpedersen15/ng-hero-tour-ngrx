export interface CharacterUrl {
  type: "detail" | "wiki" | "comiclink";
  url: string;
}
