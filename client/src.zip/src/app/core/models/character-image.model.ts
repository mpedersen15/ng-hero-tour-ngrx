export interface CharacterImage {
  path: string;
  extension: string;
}
